Style Atlas / Character Atlas wildcards
Extracted from https://github.com/atlasimp/Style_Atlas (xlsx libraries). One entry per line.
Usage in any wildcard extension:  __style_all__   __mod_lighting__   __char_random__

styles/            style_all + one file per category (1,526 styles, short version, name prefix removed)
modifiers/         mod_all + one file per modifier slot (lighting, palette, quality, ...)
characters/        ready-made random people, 1000 lines each, adults only, no pose/expression:
                   char_random, char_male, char_female, char_realistic, char_fantasy, char_scifi, char_anime
character_parts/   the individual building blocks (hair, eyes, outfits, poses, expressions, ...)
build_wildcards.py regenerates everything from the xlsx files (python build_wildcards.py <xlsx dir> <out dir>)
