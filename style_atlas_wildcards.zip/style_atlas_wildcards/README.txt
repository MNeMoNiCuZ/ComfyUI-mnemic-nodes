Style Atlas / Character Atlas wildcards
Extracted from https://github.com/atlasimp/Style_Atlas (xlsx libraries).
One entry per line, usable as __folder/file__ in any wildcard extension.
Short prompts are the main files; long/ subfolders hold the Long versions.
Style names ("Name: ...") are stripped from style/modifier lines.
Rows with Enabled = No are skipped; duplicates removed.
Regenerate with build_wildcards.py.
