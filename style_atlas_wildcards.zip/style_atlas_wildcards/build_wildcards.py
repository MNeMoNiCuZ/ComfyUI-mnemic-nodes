import os, re, sys, shutil, zipfile, openpyxl

SRC, OUT = sys.argv[1], sys.argv[2]
shutil.rmtree(OUT, ignore_errors=True)

def slug(s):
    return re.sub(r"[^a-z0-9]+", "_", s.lower().replace("&", "and")).strip("_")

def strip_name(t):
    head, sep, tail = t.partition(":")
    return tail.strip() if sep and len(head) <= 80 else t

def one_line(t):
    return re.sub(r"\s+", " ", str(t or "")).strip()

def rows(path, sheet):
    ws = openpyxl.load_workbook(path, read_only=True, data_only=True)[sheet]
    it = ws.iter_rows(values_only=True)
    h = [str(x).strip() for x in next(it)]
    for r in it:
        d = dict(zip(h, r))
        if str(d.get("Enabled", "Yes")).strip().lower() == "no":
            continue
        yield d

counts = {}
def write(rel, lines):
    seen, out = set(), []
    for l in lines:
        l = one_line(l)
        if l and l.lower() not in seen:
            seen.add(l.lower()); out.append(l)
    if not out:
        return
    p = os.path.join(OUT, rel)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    open(p, "w", encoding="utf-8", newline="\n").write("\n".join(out) + "\n")
    counts[rel] = len(out)

def pair(group, name, items, strip=False):
    """items: list of (short, long). Writes name.txt and long/name.txt."""
    f = (lambda t: strip_name(one_line(t))) if strip else one_line
    write(f"{group}/{name}.txt", [f(s or l) for s, l in items])
    write(f"{group}/long/{name}.txt", [f(l or s) for s, l in items])

# ---------------- styles ----------------
sp = os.path.join(SRC, "style_atlas_library.xlsx")
st = list(rows(sp, "Styles"))
def sget(d): return (d.get("Short Version") or "", d.get("Long Version") or "")
base = [d for d in st if d.get("Layer") != "Modifier" and any(sget(d))]
mods = [d for d in st if d.get("Layer") == "Modifier" and any(sget(d))]
pair("styles", "styles_all", [sget(d) for d in base], True)
for cat in dict.fromkeys(d["Category"] for d in base):
    pair("styles/by_category", slug(cat), [sget(d) for d in base if d["Category"] == cat], True)
pair("modifiers", "modifiers_all", [sget(d) for d in mods], True)
for cat in dict.fromkeys(d["Category"] for d in mods):
    pair("modifiers", slug(cat), [sget(d) for d in mods if d["Category"] == cat], True)

# ---------------- characters ----------------
cp = os.path.join(SRC, "character_atlas_library.xlsx")
def sl(d): return (d.get("Short_Prompt") or "", d.get("Long_Prompt") or "")
G = "characters"
pair(G, "known_characters", [sl(d) for d in rows(cp, "Known_Characters")])
pair(G, "presets_actor", [sl(d) for d in rows(cp, "Presets")])
pair(G, "archetypes", [sl(d) for d in rows(cp, "Archetypes")])
pair(G, "expressions", [sl(d) for d in rows(cp, "Expressions")])
pair(G, "poses", [sl(d) for d in rows(cp, "Poses")])
pair(G, "accessories", [sl(d) for d in rows(cp, "Accessories")])
att = list(rows(cp, "Attributes"))
for t in dict.fromkeys(d["Attribute_Type"] for d in att):
    pair(f"{G}/attributes", slug(t), [sl(d) for d in att if d["Attribute_Type"] == t])
out = list(rows(cp, "Outfits"))
for t in dict.fromkeys(d["Slot"] for d in out):
    pair(f"{G}/outfits", slug(t), [sl(d) for d in out if d["Slot"] == t])
write(f"{G}/outfits/color.txt", [d["Prompt"] for d in rows(cp, "Colors")])
write(f"{G}/outfits/pattern.txt", [d["Prompt"] for d in rows(cp, "Patterns")])
write(f"{G}/outfits/finish.txt", [d["Prompt"] for d in rows(cp, "Finishes")])
pair(f"{G}/outfits", "fabric", [sl(d) for d in rows(cp, "Fabrics")])

open(os.path.join(OUT, "README.txt"), "w").write(
"""Style Atlas / Character Atlas wildcards
Extracted from https://github.com/atlasimp/Style_Atlas (xlsx libraries).
One entry per line, usable as __folder/file__ in any wildcard extension.
Short prompts are the main files; long/ subfolders hold the Long versions.
Style names ("Name: ...") are stripped from style/modifier lines.
Rows with Enabled = No are skipped; duplicates removed.
Regenerate with build_wildcards.py.
""")
for k in sorted(counts): print(f"{counts[k]:6d} {k}")
