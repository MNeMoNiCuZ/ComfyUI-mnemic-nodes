"""Builds plain-text wildcards from the Style Atlas / Character Atlas xlsx libraries.
usage: python build_wildcards.py <dir with the two xlsx files> <output dir>"""
import os, re, sys, shutil, random, collections
import openpyxl

SRC, OUT = sys.argv[1], sys.argv[2]
N = 1000          # lines per random-character wildcard
shutil.rmtree(OUT, ignore_errors=True)


# ---------------------------------------------------------------- helpers
def slug(s):
    return re.sub(r"[^a-z0-9]+", "_", s.lower().replace("&", "and")).strip("_")

def one_line(t):
    return re.sub(r"\s+", " ", str(t or "")).strip()

def strip_name(t):
    head, sep, tail = t.partition(":")
    return tail.strip() if sep and len(head) <= 80 else t

def rows(path, sheet):
    ws = openpyxl.load_workbook(os.path.join(SRC, path), read_only=True, data_only=True)[sheet]
    it = ws.iter_rows(values_only=True)
    h = [str(x).strip() for x in next(it)]
    for r in it:
        d = dict(zip(h, r))
        if str(d.get("Enabled", "Yes")).strip().lower() != "no":
            yield d

counts = {}
def write(rel, lines):
    seen, out = set(), []
    for l in lines:
        l = one_line(l)
        if l and l.lower() not in seen:
            seen.add(l.lower()); out.append(l)
    if out:
        p = os.path.join(OUT, rel)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        open(p, "w", encoding="utf-8", newline="\n").write("\n".join(out) + "\n")
        counts[rel] = len(out)


# ---------------------------------------------------------------- styles / modifiers
st = list(rows("style_atlas_library.xlsx", "Styles"))
def stext(d): return strip_name(one_line(d.get("Short Version") or d.get("Long Version")))
base = [d for d in st if d.get("Layer") != "Modifier" and (d.get("Short Version") or d.get("Long Version"))]
mods = [d for d in st if d.get("Layer") == "Modifier" and (d.get("Short Version") or d.get("Long Version"))]
write("styles/style_all.txt", [stext(d) for d in base])
for cat in dict.fromkeys(d["Category"] for d in base):
    write(f"styles/style_{slug(cat)}.txt", [stext(d) for d in base if d["Category"] == cat])
write("modifiers/mod_all.txt", [stext(d) for d in mods])
for cat in dict.fromkeys(d["Category"] for d in mods):
    write(f"modifiers/mod_{slug(cat)}.txt", [stext(d) for d in mods if d["Category"] == cat])


# ---------------------------------------------------------------- character parts (one short list each)
CP = "character_atlas_library.xlsx"
def ptext(d): return one_line(d.get("Short_Prompt") or d.get("Long_Prompt"))
PARTS = "character_parts"
att = list(rows(CP, "Attributes"))
for t in dict.fromkeys(d["Attribute_Type"] for d in att):
    write(f"{PARTS}/part_{slug(t)}.txt", [ptext(d) for d in att if d["Attribute_Type"] == t])
outf = list(rows(CP, "Outfits"))
for t in dict.fromkeys(d["Slot"] for d in outf):
    write(f"{PARTS}/part_outfit_{slug(t)}.txt", [ptext(d) for d in outf if d["Slot"] == t])
write(f"{PARTS}/part_outfit_color.txt", [d["Prompt"] for d in rows(CP, "Colors")])
write(f"{PARTS}/part_outfit_fabric.txt", [ptext(d) for d in rows(CP, "Fabrics")])
write(f"{PARTS}/part_outfit_pattern.txt", [d["Prompt"] for d in rows(CP, "Patterns")])
write(f"{PARTS}/part_outfit_finish.txt", [d["Prompt"] for d in rows(CP, "Finishes")])
write(f"{PARTS}/part_poses.txt", [ptext(d) for d in rows(CP, "Poses")])
write(f"{PARTS}/part_expressions.txt", [ptext(d) for d in rows(CP, "Expressions")])
write(f"{PARTS}/part_accessories.txt", [ptext(d) for d in rows(CP, "Accessories")])
write(f"{PARTS}/part_archetypes.txt", [ptext(d) for d in rows(CP, "Archetypes")])


# ---------------------------------------------------------------- random characters
ATT = collections.defaultdict(list)
for d in att:
    ATT[d["Attribute_Type"]].append(d)
OUTF = collections.defaultdict(list)
for d in outf:
    OUTF[d["Slot"]].append(d)
COLORS = list(rows(CP, "Colors"))
FABRICS = list(rows(CP, "Fabrics"))
PATTERNS = [d for d in rows(CP, "Patterns") if d.get("Prompt")]
FINISHES = [d for d in rows(CP, "Finishes") if d.get("Prompt")]
ACCS = list(rows(CP, "Accessories"))

def rx(p): return re.compile(p, re.I)
def sel(rowsl, names=None, cats=None, ex=None, key="Name"):
    out = []
    for d in rowsl:
        n = d[key]
        if names is not None and n not in names and not (cats and d.get("Category") in cats):
            continue
        if names is None and cats and d.get("Category") not in cats:
            continue
        if ex and rx(ex).search(n):
            continue
        out.append(d)
    return out

# ---- gender rules (the library marks outfits/accessories as "All", so these are name filters)
M_TOP = rx(r"Crop|Tube|Bandeau|Halter|Spaghetti|Camisole|Corset|Bustier|Wrap Top|Peplum|Off-Shoulder|"
           r"One-Shoulder|Pussy|Ruffled|Puff|Lace|Sports Bra|Cheerleader|Qipao|Choli|Bodice|Maid|Mesh|Peasant|Blouse")
M_BOT = rx(r"Skirt|Sarong|Bloomers|Hot Pants|Hoop|Mermaid|Leggings|Yoga|High-Waisted")
M_FULL = rx(r"Dress|Gown|Lolita|Pinafore|Babydoll|Dirndl|Sari|Qipao|Ao Dai|Furisode|Abaya|Maid|"
            r"Flight Attendant|Bikini|Leotard|Swimsuit|Idol|Magical Girl|Priestess|Valkyrie|Flapper")
M_FOOT = rx(r"Stiletto|Pumps|Mary Janes|Ballet|Pointe|Wedge|Strappy|Thigh-High")
M_ACC = rx(r"Earring|Hair|Ribbon|Bow|Tiara|Choker|Garter|Handbag|Clutch|Stocking|Tights|Lace|Maid|Bunny|"
           r"Cat Ear|Fox Ear|Pearl|Scrunchie|Headband|Veil|Boa|Jabot|Kanzashi|Flower|Fascinator|Parasol|"
           r"Belly|Bonnet|Hairpin|Fishnet|Socks|Leg Warmers|Anklet|Detached|Nail|Kitsune Mask|Beauty Mark")
F_HAIR = rx(r"Buzz Cut|Crew Cut|Mullet")
F_TOP = rx(r"Gakuran")
BAD_SHAPE = rx(r"Pregnant|Maternal|Chibi|Fashion Croquis|Heroic Comic|Boyish|Androgynous")
OLD_SHAPE = rx(r"Elderly")
MATURE_SHAPE = rx(r"Elegant Mature")
STYLIZED_FACE = rx(r"tareme|tsurime|anime|chibi|manga|cartoon")
HUMAN_SKIN_BAD = rx(r"Blue Skin|Green Skin|Grey Skin")
REAL_PATTERN_BAD = rx(r"hanfu|seigaiha|asanoha|sakura|damask|toile|zebra|tiger|snake|cow|digital camo|art deco|ikat|batik|heart|star print|graphic logo|embroidered|patchwork|gradient|tropical|tie-dye")
FINISH_BAD = rx(r"tattered|spiked|laser|mesh|wet look|rhinestone|sequin|cut-out|pearlescent|fur-trimmed|gold-trimmed|cropped|oversized|fitted|layered|ripped|appliqued|studded")
M_HAIR_OK = rx(r"Undercut|Buzz|Crew|Short Shag|Textured Pixie|Wolf Cut|Mullet|Shag|Feathered|Shoulder-Length|"
               r"Long Straight|Long Wavy|Long Layered|Long Curly|Long Sleek|Top Knot|Messy Bun|Half Bun|"
               r"Single Braid|French Braid|Dutch Braid|Box Braids|Cornrows|Low Ponytail|High Ponytail|"
               r"Short Ponytail|Sleek Ponytail|Afro|Twist Out|Bantu|Coily|Kinky|Spiky|Gravity|One Eye|"
               r"Asymmetrical Anime|Long Sidelocks|Pompadour|1970s|1980s|Marcel|Pixie Cut|Long Pixie|"
               r"Side Undercut|Medium Textured|Silk Press|Fade|Quiff|Slick")

NATURAL_HAIR = ["Jet Black", "Black", "Dark Brown", "Chestnut Brown", "Light Brown", "Honey Blonde",
                "Golden Blonde", "Platinum Blonde", "Ash Blonde", "Strawberry Blonde", "Auburn", "Copper Red",
                "Bright Red", "Ginger", "Blonde with Dark Roots"]
OLD_HAIR = ["Silver", "White", "Grey", "Salt and Pepper"]
NATURAL_EYES = ["Brown Eyes", "Dark Brown Eyes", "Hazel Eyes", "Amber Eyes", "Green Eyes", "Emerald Eyes",
                "Blue Eyes", "Ice Blue Eyes", "Grey Eyes", "Black Eyes"]
REAL_DIST = ["Beauty Mark", "Freckles", "Scar Across Eye", "Scar on Cheek", "Dimples", "Gap Teeth",
             "Vitiligo", "Birthmark", "Burn Scar"]

# ---- per-profile outfit / accessory pools
def P(top, bottom, full, outer, foot, **kw):
    kw.setdefault("realistic_mods", True)
    return dict(top=top, bottom=bottom, full=full, outer=outer, foot=foot, **kw)

PROFILES = {
 "realistic": P(
   top=sel(OUTF["Top"], cats=["Casual", "Formal"], names=["Nurse Top", "Chef Jacket", "Sports Bra"],
           ex=r"Peasant|Corset|Bustier|Sheer Mesh"),
   bottom=sel(OUTF["Bottom"], cats=["Pants", "Shorts", "Skirts"],
              ex=r"Hakama|Harem|Kilt|Sarong|Bloomers|Hoop|Bubble|Mermaid|Tulle|Tactical|School"),
   full=sel(OUTF["Full Body"], cats=["Dresses"], names=["Business Suit", "Tuxedo", "Swimsuit", "Gym Uniform",
            "Mechanic Jumpsuit", "Lab Coat Ensemble", "Police Uniform", "Nurse Uniform", "Flight Attendant Uniform"],
            ex=r"Lolita|Babydoll|Flapper|Prairie|Mermaid Gown|Pinafore"),
   outer=sel(OUTF["Outerwear"], ex=r"Cape|Cloak|Tailcoat|Haori|Kimono|Greatcoat|Cyberpunk|Sukajan|Poncho|Shawl"),
   foot=sel(OUTF["Footwear"], ex=r"Armored|Geta|Zori|Pointe|Moccasins|Barefoot"),
   types={"Human": 1}, fabrics=["Natural", "Denim and Workwear", "Knit", "Luxury", "Leather and Fur"],
   fabric_ex=r"Sequins|Beaded|Lame|Mesh|Fishnet|Fur Trim|Snakeskin|Crocodile|Organza|Chiffon|Georgette|Taffeta|Tulle|Brocade|Damask|Jacquard|Charmeuse|Lace",
   colors=["Neutrals", "Reds and Pinks", "Blues", "Greens", "Oranges and Yellows", "Purples", "Pastel"],
   hair_cats=["Short", "Medium", "Long", "Ponytail", "Bun", "Braid", "Textured"], hair_cat_ex=[], hair_ex=r"Space Buns|Odango|Drill|Beehive|Twin|Ox-Horn|Bubble",hair_color_ex=r"^$",
   natural=True, dist=REAL_DIST,
   acc=sel(ACCS, cats=["Headwear", "Eyewear", "Earrings", "Neckwear", "Hands and Wrists", "Waist", "Bags",
                       "Handheld", "Hair Accessories", "Legwear"],
           ex=r"Witch|Wizard|Pirate|Conical|Cat Ear|Bunny|Fox Ear|Devil|Halo|Maid|Nurse Cap|Chef Hat|Captain|"
              r"Military|Kasa|Steampunk|Cyber|Blindfold|Eyepatch|Masquerade|Domino|Lace Eye|Monocle|Aviator Goggles|"
              r"Ski Goggles|Torque|Tribal|Collar Bell|Boa|Sailor|Gauntlet|Bandaged|Hand Chain|Boxing|MMA|Spiked|"
              r"Detached|Chain Belt|Obi|Holster|Cartridge|Utility|Tool Belt|Rope Belt|Belly|Randoseru|Basket|Quiver|"
              r"Potion|Spellbook|Crystal Ball|Hourglass|Map Scroll|Balloon|Teddy|Plush|Lantern|Candle|Cigarette|"
              r"Tiara|Crown|Diadem|Circlet|Laurel|Feather|Veil|Bonnet|Kanzashi|Hair Stick|Ahoge|Bun Cover|Hair Chain|"
              r"Hair Beads|Hair Cuffs|Star Hair|Twin Hair|Alice|Pillbox|Cloche|Fascinator|Top Hat|Mini Top|Graduation|"
              r"Garter|Leg Wraps|Knee Pads|Shin|Hood$|Sweatband|Parasol|Fan$|Bubble Tea|Skateboard|Basketball|Tennis|Guitar|Violin|Microphone|Game Controller|Paintbrush|Teddy|Magnifying|Pocket Watch|Cane")),
 "fantasy": P(
   top=sel(OUTF["Top"], cats=["Fantasy"], names=["Waistcoat", "Peasant Blouse", "Puff Sleeve Blouse", "Corset Top",
           "Wrap Top", "Lace Blouse"], ex=r"Cyberpunk|Space|Steampunk|Gothic Lace"),
   bottom=sel(OUTF["Bottom"], cats=["Fantasy"], names=["Leather Pants", "Maxi Skirt", "Midi Skirt", "Tiered Skirt",
              "Wrap Skirt", "Slit Skirt", "Tailored Trousers", "Kilt"], ex=r"Cyberpunk"),
   full=sel(OUTF["Full Body"], cats=["Fantasy"], names=["Evening Gown", "Ball Gown", "Maxi Dress", "Wrap Dress",
            "Toga", "Kaftan", "Mermaid Gown", "Wedding Dress"],
            ex=r"Superhero|Cyberpunk|Space Suit|Mecha|Steampunk|Idol|Magical Girl"),
   outer=sel(OUTF["Outerwear"], names=["Cape", "Hooded Cloak", "Fur Coat", "Faux Fur Jacket", "Long Wool Coat",
             "Duster Coat", "Shawl Wrap", "Poncho", "Military Greatcoat", "Tailcoat"]),
   foot=sel(OUTF["Footwear"], names=["Knee-High Boots", "Thigh-High Boots", "Ankle Boots", "Riding Boots",
            "Combat Boots", "Armored Greaves", "Moccasins", "Strappy Sandals", "Barefoot", "Cowboy Boots",
            "Platform Boots"]),
   types={"Human": 3, "Elf": 3, "Half-Elf": 1, "Dwarf": 2, "Orc": 2, "Demon": 2, "Angel": 1, "Vampire": 2,
          "Fae": 1, "Dragonkin": 1, "Undead": 1, "Kitsune": 1, "Kemonomimi": 1},
   fabrics=["Natural", "Luxury", "Leather and Fur"],
   fabric_ex=r"Sequins|Lame|Fishnet|Mesh|Beaded|Snakeskin|Crocodile",
   colors=["Neutrals", "Reds and Pinks", "Blues", "Greens", "Oranges and Yellows", "Purples", "Metallic"],
   hair_cats=None, hair_cat_ex=["Anime", "Historical"], hair_ex=r"Twin|Space Buns|Odango|Ox-Horn|Bubble|Drill",hair_color_ex=r"Rainbow|Ombre|Two-Tone|Pastel|Hot Pink|Mint|Streak",
   natural=False, dist=REAL_DIST + ["Facial Tattoo", "Glowing Eyes"],
   acc=sel(ACCS, cats=["Weapons", "Fantasy and Sci-Fi", "Body", "Waist", "Hands and Wrists", "Neckwear", "Bags",
                       "Earrings", "Headwear", "Hair Accessories", "Handheld", "Face"],
           names=None,
           ex=r"Revolver|Pistol|Rifle|Shotgun|Ray Gun|Energy Sword|Mechanical Wings|Cybernetic|Circuit|Jetpack|"
              r"Holographic|Power Armor|Robot|Drone|Smartphone|Camera|Smartwatch|Wristwatch|Baseball|Snapback|Beanie|"
              r"Bucket|Visor|Sunglasses|Glasses|Headphones|Game Controller|Skateboard|Basketball|Tennis|Backpack|"
              r"Tote|Messenger|Duffel|Randoseru|Briefcase|Fanny|Surgical|Cloth Face|Gas Mask|Respirator|Hockey|"
              r"Nail|Bubble Tea|Coffee|Balloon|Hoodie|Name Tag|Medal|Lapel|Corsage|Rosette|Maid|Nurse|Chef|Graduation|"
              r"Band-Aid|Bandage on|Beauty Mark Sticker|Freckle|Glitter|Smart|Instant|Vintage Camera|Book$|Sketchbook|"
              r"Paintbrush|Guitar|Violin|Microphone|Cigarette|Letter|Teddy|Plush|Boxing|MMA|Knee Pads|Shin")),
 "scifi": P(
   top=sel(OUTF["Top"], names=["Cyberpunk Mesh Top", "Space Suit Top", "Armored Crop Top", "Tactical Vest",
           "Military Shirt", "Turtleneck", "Tank Top", "Crop Top", "Long-Sleeve Tee", "Hoodie", "Sheer Mesh Top",
           "Sports Bra"]),
   bottom=sel(OUTF["Bottom"], names=["Cyberpunk Pants", "Tactical Pants", "Leggings", "Cargo Pants", "Leather Pants",
              "Joggers", "Skinny Jeans", "Bike Shorts", "Leather Miniskirt"]),
   full=sel(OUTF["Full Body"], names=["Cyberpunk Bodysuit", "Space Suit", "Mecha Pilot Suit", "Plugsuit", "Racing Suit",
            "Pilot Jumpsuit", "Mechanic Jumpsuit", "Superhero Suit", "Leotard", "Business Suit", "Lab Coat Ensemble"]),
   outer=sel(OUTF["Outerwear"], names=["Cyberpunk Techwear Jacket", "Leather Biker Jacket", "Bomber Jacket",
             "Trench Coat", "Windbreaker", "Lab Coat", "Cropped Jacket", "Puffer Jacket"]),
   foot=sel(OUTF["Footwear"], names=["Combat Boots", "Platform Boots", "Sneakers", "High-Top Sneakers",
            "Platform Sneakers", "Knee-High Boots", "Thigh-High Boots", "Chelsea Boots", "Ankle Boots", "Running Shoes"]),
   types={"Human": 5, "Android": 3, "Cyborg": 3, "Alien": 2, "Robot": 1},
   fabrics=["Synthetic and Technical", "Leather and Fur", "Knit"], fabric_ex=r"Fur Trim|Faux Fur|Snakeskin|Crocodile|Terry|Crochet",
   colors=["Neutrals", "Neon", "Metallic", "Blues", "Purples", "Reds and Pinks", "Greens"],
   hair_cats=None, hair_cat_ex=["Anime", "Historical"], hair_ex=r"Twin|Space Buns|Odango|Ox-Horn|Bubble|Drill",hair_color_ex=r"Rainbow|Pastel|Ombre|Mint|Two-Tone",
   natural=False, dist=REAL_DIST + ["Facial Tattoo", "Glowing Eyes", "Mechanical Eye", "Cybernetic Jaw"],
   acc=sel(ACCS, names=["Cyber Visor", "Aviator Goggles", "Aviator Sunglasses", "Shield Sunglasses", "Round Sunglasses",
           "Cybernetic Arm", "Cybernetic Eye", "Glowing Circuit Tattoos", "Jetpack", "Holographic Wrist Display",
           "Power Armor Gauntlet", "Robot Companion Drone", "Mechanical Wings", "Revolver", "Twin Pistols", "Rifle",
           "Shotgun", "Ray Gun", "Energy Sword", "Gas Mask", "Respirator", "Face Gems", "Smartwatch", "Fingerless Gloves",
           "Leather Gloves", "Hood", "Visor Cap", "Choker", "Dog Tags", "Utility Belt", "Thigh Holster", "Backpack",
           "Headphones Around Neck", "Smartphone", "Earring", "Ear Cuff", "Stud Earrings", "Tattoo Sleeve", "Harness Straps",
           "Body Chain", "Combat Knee Pads", "Knee Pads", "Stacked Rings"])),
 "anime": P(
   top=sel(OUTF["Top"], names=["Sailor Uniform Top", "Blazer School Top", "Gakuran Jacket", "Maid Top with Apron Bib",
           "Crop Top", "Oversized T-Shirt", "Cropped Hoodie", "Hoodie", "Cardigan", "Off-Shoulder Sweater", "Camisole",
           "Knit Sweater", "Turtleneck", "Sweatshirt", "Kimono Top", "Cheerleader Top", "Graphic T-Shirt", "Tank Top",
           "Henley Shirt", "Button-Up Shirt", "Armored Crop Top"]),
   bottom=sel(OUTF["Bottom"], names=["Pleated School Skirt", "Pleated Miniskirt", "Plaid Skirt", "Tennis Skirt",
              "Denim Shorts", "Skinny Jeans", "Leggings", "Bike Shorts", "Tiered Skirt", "Wide-Leg Jeans", "Cargo Pants",
              "Joggers", "Track Pants", "High-Waisted Shorts", "Hakama", "Overalls"]),
   full=sel(OUTF["Full Body"], names=["Maid Uniform", "Magical Girl Dress", "Idol Stage Outfit", "Plugsuit", "Kimono",
            "Yukata", "Gym Uniform", "Gothic Lolita Dress", "Sweet Lolita Dress", "Lolita Dress", "Sundress", "Swimsuit",
            "Witch Dress", "Nurse Uniform", "Samurai Armor", "Ninja Garb", "Qipao", "Hanfu", "Little Black Dress",
            "Pinafore Dress", "Wizard Robes", "Priestess Robes", "Leotard", "Mecha Pilot Suit"]),
   outer=sel(OUTF["Outerwear"], names=["Haori", "Kimono Jacket", "Sukajan Souvenir Jacket", "Bomber Jacket",
             "Varsity Jacket", "Windbreaker", "Denim Jacket", "Cropped Jacket", "Track Jacket", "Cape", "Hooded Cloak",
             "Oversized Blazer", "Trench Coat", "Peacoat"]),
   foot=sel(OUTF["Footwear"], names=["Sneakers", "High-Top Sneakers", "Platform Sneakers", "Loafers", "Mary Janes",
            "Platform Mary Janes", "Knee-High Boots", "Thigh-High Boots", "Ankle Boots", "Platform Boots", "Geta", "Zori",
            "Combat Boots", "Ballet Flats", "Pumps"]),
   types={"Human": 16, "Kemonomimi": 2, "Kitsune": 1, "Elf": 1}, realistic_mods=False, fabrics=["Natural", "Knit", "Luxury", "Denim and Workwear"],
   fabric_ex=r"Sequins|Lame|Fishnet|Mesh|Beaded|Organza|Chiffon|Georgette|Taffeta|Charmeuse", colors=None,
   hair_cats=None, hair_cat_ex=["Historical"], hair_ex=r"^$",hair_color_ex=r"^$",
   natural=False, dist=REAL_DIST + ["Facial Tattoo", "Glowing Eyes"],
   acc=sel(ACCS, cats=["Hair Accessories", "Headwear", "Eyewear", "Earrings", "Neckwear", "Hands and Wrists", "Waist",
                       "Bags", "Handheld", "Legwear"],
           ex=r"Torque|Tribal|Plague|Gauntlet|Boxing|MMA|Bandaged|Spiked|Cartridge|Holster|Obi|Tool Belt|Rope Belt|"
              r"Steampunk|Cyber|Blindfold|Pirate|Witch|Wizard|Military|Captain|Smart|Skateboard|Basketball|Tennis|"
              r"Cigarette|Balloon|Hockey")),
}
# creature extras: item name -> only allowed for these types
CREATURE = {"Angel Wings": {"Angel"}, "Feathered Black Wings": {"Angel", "Demon"}, "Halo Ring": {"Angel"},
            "Bat Wings": {"Demon", "Vampire"}, "Demon Horns": {"Demon", "Dragonkin"},
            "Curled Ram Horns": {"Demon"}, "Devil Tail": {"Demon"}, "Fairy Wings": {"Fae"},
            "Butterfly Wings": {"Fae"}, "Unicorn Horn": {"Fae"}, "Fox Tail": {"Kitsune"}, "Cat Tail": {"Kemonomimi"},
            "Familiar Spirit": None}
for prof in PROFILES.values():
    for a in ACCS:
        if a["Name"] in ("Cat Ear Headband", "Fox Ear Headband", "Devil Horn Headband", "Halo Headpiece"):
            pass  # accessories like these stay excluded unless listed in the profile

TYPE_DIST = {"Elf": ["Elf Ears", "Pointed Ears"], "Half-Elf": ["Pointed Ears"], "Fae": ["Pointed Ears"],
             "Orc": ["Fangs"], "Vampire": ["Fangs"], "Demon": ["Horns", "Glowing Eyes", "Fangs"],
             "Dragonkin": ["Horns"], "Kitsune": ["Animal Tail", "Cat Ears"], "Kemonomimi": ["Cat Ears", "Animal Tail"],
             "Undead": ["Glowing Eyes", "Burn Scar"]}
AGES = [("Young Adult", 36), ("Adult", 36), ("Middle-Aged", 14), ("Mature", 8), ("Elderly", 6)]  # no Child/Teen
ATTR = {t: {d["Name"]: d for d in v} for t, v in ATT.items()}

def wchoice(rng, items):
    return rng.choices([i for i, _ in items], weights=[w for _, w in items])[0]

def text(d): return ptext(d)

def garment(rng, d, slot, colors, prof):
    term = d.get("Garment_Term") or text(d)
    fabric = d.get("Default_Fabric") or ""
    pattern = d.get("Default_Pattern") or ""
    color = finish = ""
    if rng.random() < 0.7 and colors:
        color = rng.choice(colors)
    if rng.random() < 0.12 and slot != "Footwear":
        fin = [f for f in FINISHES if not (prof["realistic_mods"] and FINISH_BAD.search(f["Prompt"]))]
        finish = rng.choice(fin)["Prompt"]
    if rng.random() < 0.10 and slot in ("Top", "Bottom", "Outerwear"):
        pat = [p for p in PATTERNS if not (prof["realistic_mods"] and REAL_PATTERN_BAD.search(p["Prompt"]))]
        pattern = rng.choice(pat)["Prompt"]
    if slot != "Footwear" and rng.random() < (0.1 if slot == "Full Body" else 0.2):
        fs = [f for f in FABRICS if slot in (f.get("Applies_To") or "") and f["Category"] in prof["fabrics"]
              and not rx(prof["fabric_ex"]).search(f["Name"])]
        if fs:
            fabric = text(rng.choice(fs))
    low = term.lower()
    def new(x):  # skip modifiers whose words the garment name already contains
        return x and not any(w in low for w in x.lower().replace("-", " ").split() if len(w) > 3)
    return " ".join(x for x in (finish if new(finish) else "", color, pattern if new(pattern) else "",
                                fabric if new(fabric) else "", term) if x)

def and_list(items):
    return items[0] if len(items) == 1 else ", ".join(items[:-1]) + " and " + items[-1]

def make(rng, gender, profile):
    prof = PROFILES[profile]
    male = gender == "M"
    ctype = wchoice(rng, list(prof["types"].items()))
    age = wchoice(rng, [(a, w) for a, w in AGES if not (profile == "anime" and a in ("Mature", "Elderly"))])
    age_word = text(ATTR["Age"][age])
    noun = "man" if male else "woman"
    type_word = "" if ctype == "Human" else text(ATTR["Character Type"][ctype])
    parts = [" ".join(x for x in (age_word, type_word, noun) if x)]

    if rng.random() < 0.5:
        parts.append(text(rng.choice(ATT["Height"])))
    bs = [d for d in ATT["Body Shape"] if d["Gender"] == ("Male" if male else "Female")
          and not BAD_SHAPE.search(d["Name"]) and not OLD_SHAPE.search(d["Name"])
          and not MATURE_SHAPE.search(d["Name"]) and not (d["Name"] == "Anime Idealized" and profile != "anime")]
    if age == "Elderly" and rng.random() < .5:
        bs = [d for d in ATT["Body Shape"] if OLD_SHAPE.search(d["Name"]) and d["Gender"] == ("Male" if male else "Female")]
    elif age in ("Mature", "Middle-Aged") and not male and rng.random() < .3:
        bs = [d for d in ATT["Body Shape"] if MATURE_SHAPE.search(d["Name"])]
    parts.append(text(rng.choice(bs)))
    for t, p in (("Face Shape", .4), ("Jaw", .3), ("Cheekbones", .25), ("Eyebrows", .4), ("Eye Shape", .4),
                 ("Nose", .4), ("Lips", .4)):
        if rng.random() < p:
            parts.append(text(rng.choice([d for d in ATT[t] if not (prof["natural"] and STYLIZED_FACE.search(d["Name"]))])))
    if not male and rng.random() < .3:
        parts.append(text(rng.choice(ATT["Eyelashes"])))
    eyes = [d for d in ATT["Eye Color"] if not prof["natural"] or d["Name"] in NATURAL_EYES]
    parts.append(text(rng.choice(eyes)))
    nonhuman = ctype != "Human"
    parts.append(text(rng.choice([d for d in ATT["Complexion"]
                                  if nonhuman or not HUMAN_SKIN_BAD.search(d["Name"])])))
    if male and rng.random() < (.15 if profile == "anime" else .45):
        parts.append(text(rng.choice(ATT["Facial Hair"])))
    dnames = list(prof["dist"]) + TYPE_DIST.get(ctype, [])
    if ctype in TYPE_DIST and rng.random() < .6:
        dnames = TYPE_DIST[ctype]
    if rng.random() < .25 or (ctype in TYPE_DIST and rng.random() < .5):
        parts.append(text(ATTR["Distinctive"][rng.choice(dnames)]))

    # hair
    old = age in ("Elderly", "Mature")
    if prof["natural"]:
        pool = OLD_HAIR if old and rng.random() < .75 else NATURAL_HAIR
    else:
        pool = [n for n in ATTR["Hair Color"] if not rx(prof["hair_color_ex"]).search(n)]
        if not old:
            pool = [n for n in pool if n not in ("Grey", "Salt and Pepper")]
    parts.append(text(ATTR["Hair Color"][rng.choice(pool)]))
    hs = [d for d in ATT["Hair Style"]
          if (not prof["hair_cats"] or d["Category"] in prof["hair_cats"])
          and d["Category"] not in (prof.get("hair_cat_ex") or [])
          and not rx(prof["hair_ex"]).search(d["Name"])]
    hs = [d for d in hs if (M_HAIR_OK.search(d["Name"]) if male else not F_HAIR.search(d["Name"]))]
    parts.append(text(rng.choice(hs)))

    # outfit
    colors_all = [d for d in COLORS if not prof["colors"] or d["Category"] in prof["colors"]]
    cols = [d["Prompt"] for d in rng.sample(colors_all, 2)]
    def ok(d, bad):
        return not (male and bad.search(d["Name"]) and d["Name"] != "Kilt")
    full = rng.random() < .3
    garments = []
    if full:
        garments.append(garment(rng, rng.choice([d for d in prof["full"] if ok(d, M_FULL)]), "Full Body", cols, prof))
    else:
        garments.append(garment(rng, rng.choice([d for d in prof["top"] if ok(d, M_TOP)
                                                 and (male or not F_TOP.search(d["Name"]))]), "Top", cols, prof))
        garments.append(garment(rng, rng.choice([d for d in prof["bottom"] if ok(d, M_BOT)]), "Bottom", cols, prof))
    if rng.random() < .4:
        garments.append(garment(rng, rng.choice(prof["outer"]), "Outerwear", cols, prof))
    if rng.random() < .85:
        garments.append(garment(rng, rng.choice([d for d in prof["foot"] if ok(d, M_FOOT)]), "Footwear", cols, prof))

    # accessories (0-3)
    accs = []
    pool = [d for d in prof["acc"] if not (male and M_ACC.search(d["Name"]))
            and (d["Name"] not in CREATURE or (CREATURE[d["Name"]] and ctype in CREATURE[d["Name"]]))]
    extras = [d for d in ACCS if d["Name"] in CREATURE and CREATURE[d["Name"]] and ctype in CREATURE[d["Name"]]
              and profile in ("fantasy", "scifi", "anime")]
    for d in rng.sample(pool, k=min(len(pool), wchoice(rng, [(0, 1), (1, 3), (2, 3), (3, 1)]))) + \
             (rng.sample(extras, 1) if extras and rng.random() < .5 else []):
        n = text(d)
        if rng.random() < .3 and d["Category"] in ("Headwear", "Neckwear", "Hands and Wrists", "Waist", "Bags",
                                                   "Earrings", "Hair Accessories", "Legwear") and colors_all:
            n = rng.choice(cols) + " " + n
        accs.append(n)

    chunks = [", ".join(parts), "wearing " + and_list(garments)]
    if accs:
        chunks.append("with " + and_list(accs))
    return ", ".join(chunks)

def generate(name, gender_w, profile_w, seed):
    rng = random.Random(seed)
    out, seen, tries = [], set(), 0
    while len(out) < N and tries < N * 20:
        tries += 1
        g = wchoice(rng, gender_w)
        pr = wchoice(rng, profile_w)
        line = one_line(make(rng, g, pr))
        if line.lower() not in seen:
            seen.add(line.lower()); out.append(line)
    write(f"characters/{name}.txt", out)

MIX = [("realistic", 5), ("fantasy", 2), ("scifi", 1), ("anime", 2)]
BOTH = [("F", 1), ("M", 1)]
generate("char_random", BOTH, MIX, 1)
generate("char_male", [("M", 1)], MIX, 2)
generate("char_female", [("F", 1)], MIX, 3)
generate("char_realistic", BOTH, [("realistic", 1)], 4)
generate("char_fantasy", BOTH, [("fantasy", 1)], 5)
generate("char_scifi", BOTH, [("scifi", 1)], 6)
generate("char_anime", [("F", 3), ("M", 2)], [("anime", 1)], 7)

open(os.path.join(OUT, "README.txt"), "w", encoding="utf-8").write(
"""Style Atlas / Character Atlas wildcards
Extracted from https://github.com/atlasimp/Style_Atlas (xlsx libraries). One entry per line.
Usage in any wildcard extension:  __style_all__   __mod_lighting__   __char_random__

styles/            style_all + one file per category (1,526 styles, short version, name prefix removed)
modifiers/         mod_all + one file per modifier slot (lighting, palette, quality, ...)
characters/        ready-made random people, 1000 lines each, adults only, no pose/expression:
                   char_random, char_male, char_female, char_realistic, char_fantasy, char_scifi, char_anime
character_parts/   the individual building blocks (hair, eyes, outfits, poses, expressions, ...)
build_wildcards.py regenerates everything from the xlsx files (python build_wildcards.py <xlsx dir> <out dir>)
""")
for k in sorted(counts): print(f"{counts[k]:6d} {k}")
